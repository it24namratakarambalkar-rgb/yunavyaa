(function ($) {
  "use strict";

  // Initialize WOW.js for animations
  new WOW().init();

  // Navbar Cart Open
  $(".cart_link > a").on("click", function (e) {
    e.preventDefault();
    $(".mini_cart").addClass("active");
  });

  // Navbar Cart Close
  $(".mini_cart_close > a").on("click", function (e) {
    e.preventDefault();
    $(".mini_cart").removeClass("active");
  });

  // Sticky Navbar
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();
    if (scroll < 100) {
      $(".sticky-header").removeClass("sticky");
    } else {
      $(".sticky-header").addClass("sticky");
    }
  });

})(jQuery);

/************background image*********** */

// background image
  function dataBackgroundImage() {
    $("[data-bgimg]").each(function () {
      var bgImgUrl = $(this).data("bgimg");
      $(this).css({
        "background-image": "url(" + bgImgUrl + ")", // concatenation
      });
    });
  }

  $(window).on("load", function () {
    dataBackgroundImage();
  });
/************background image ends*********** */


$(document).ready(function(){
  $(".slider_area").owlCarousel({
    items: 1,
    loop: true,
    autoplay: true,
    autoplayTimeout: 4000,
    autoplayHoverPause: true,
    animateOut: "fadeOut",
    dots: true,
    nav: true,
    navText: [
      "<ion-icon name='chevron-back-outline'></ion-icon>",
      "<ion-icon name='chevron-forward-outline'></ion-icon>"
    ]
  });
});
